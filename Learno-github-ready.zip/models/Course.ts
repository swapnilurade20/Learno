import mongoose, { Schema } from "mongoose";

const CourseSchema = new Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  category: String,
  level: { type: String, default: "Beginner" },
  price: { type: Number, default: 0 },
  status: { type: String, enum: ["draft","published"], default: "draft" },
  modules: [{
    title: String,
    description: String,
    lessons: [{
      title: String,
      description: String,
      videoUrl: String,
      duration: Number
    }]
  }]
}, { timestamps: true });

export default mongoose.models.Course || mongoose.model("Course", CourseSchema);
