import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import Career from "@/models/Career";

export async function GET(){
  const userId=await getSessionUserId();
  if(!userId)return NextResponse.json({message:"Login required."},{status:401});
  await db();
  const a=await Career.findOne({userId}).sort({createdAt:-1});
  return NextResponse.json(a);
}
