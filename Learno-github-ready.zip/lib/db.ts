import mongoose from "mongoose";

const uri = process.env.MONGODB_URI;
if (!uri) throw new Error("MONGODB_URI is not configured");

let cached = (globalThis as any).__mongoose;
if (!cached) cached = (globalThis as any).__mongoose = { conn: null, promise: null };

export async function db() {
  if (cached.conn) return cached.conn;
  if (!cached.promise) cached.promise = mongoose.connect(uri);
  cached.conn = await cached.promise;
  return cached.conn;
}
