import "dotenv/config";
import mongoose from "mongoose";
import crypto from "crypto";
import User from "../models/User";
import Course from "../models/Course";
import Task from "../models/Task";

const hash=(p:string)=>crypto.createHash("sha256").update(p).digest("hex");

async function seed(){
 if(!process.env.MONGODB_URI)throw new Error("MONGODB_URI missing");
 await mongoose.connect(process.env.MONGODB_URI);
 await User.findOneAndUpdate({email:"admin@skillpath.local"},{name:"SkillPath Admin",email:"admin@skillpath.local",passwordHash:hash("Admin@12345"),role:"admin"},{upsert:true});
 await User.findOneAndUpdate({email:"student@skillpath.local"},{name:"Demo Student",email:"student@skillpath.local",passwordHash:hash("Student@12345"),role:"student"},{upsert:true});
 const course=await Course.findOneAndUpdate({title:"Digital Marketing for Beginners"},{title:"Digital Marketing for Beginners",description:"Learn digital marketing by completing practical work.",category:"marketing",level:"Beginner",price:5000,status:"published",modules:[{title:"Marketing Fundamentals",lessons:[{title:"Understanding Customers",description:"Learn customer research."},{title:"Content Strategy",description:"Plan content."}]},{title:"Campaigns",lessons:[{title:"Advertising Basics",description:"Learn campaign structure."}]}]},{upsert:true,new:true});
 await Task.deleteMany({courseId:course._id});
 await Task.insertMany([
 {courseId:course._id,title:"Create a Customer Persona",description:"Research a target customer and create a practical customer persona.",instructions:"Include age, problem, goal, buying behavior and preferred channel.",type:"project",xp:100,passingScore:60,order:1,published:true,rubric:[{criterion:"Understanding",description:"Shows clear understanding.",weight:35},{criterion:"Research",description:"Uses relevant information.",weight:30},{criterion:"Application",description:"Useful for marketing decisions.",weight:35}]},
 {courseId:course._id,title:"Create a 7-Day Content Plan",description:"Create seven social posts for a chosen business.",instructions:"Include topic, format, audience and CTA.",type:"project",xp:150,passingScore:60,order:2,published:true,rubric:[{criterion:"Strategy",description:"Supports a business goal.",weight:35},{criterion:"Consistency",description:"Forms a coherent plan.",weight:25},{criterion:"Practical Application",description:"Posts are realistic.",weight:40}]},
 {courseId:course._id,title:"Final Marketing Campaign",description:"Create a complete campaign strategy for a real or imaginary business.",instructions:"Include audience, offer, content, channel, budget and KPIs.",type:"project",xp:500,passingScore:70,order:3,published:true,rubric:[{criterion:"Research",description:"Uses a strong customer insight.",weight:20},{criterion:"Strategy",description:"Campaign has a clear strategy.",weight:30},{criterion:"Execution",description:"Plan is practical.",weight:30},{criterion:"Measurement",description:"KPIs are appropriate.",weight:20}]}
 ]);
 console.log("SkillPath seed complete");
 await mongoose.disconnect();
}
seed().catch(e=>{console.error(e);process.exit(1)});
