import { NextResponse } from "next/server";
import OpenAI from "openai";

export async function POST(req:Request){
  const {question,context}=await req.json();
  if(!question)return NextResponse.json({message:"Question required."},{status:400});
  if(!process.env.OPENAI_API_KEY){
    return NextResponse.json({answer:"Demo mode: connect OPENAI_API_KEY to enable the live AI doubt solver. Start by breaking the question into: what you know, what you need to find, and the next practical step."});
  }
  const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
  const r=await client.responses.create({
    model:process.env.OPENAI_MODEL||"gpt-5",
    input:`You are a friendly tutor. Explain simply and practically. Course context: ${context||"general learning"}. Student question: ${question}`
  });
  return NextResponse.json({answer:r.output_text});
}
