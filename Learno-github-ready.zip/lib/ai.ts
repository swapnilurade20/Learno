import OpenAI from "openai";

export async function evaluateWithAI(task: any, submission: string) {
  if (!process.env.OPENAI_API_KEY) {
    const score = 70;
    return {
      score,
      passed: score >= task.passingScore,
      feedback: "Demo evaluation: submission received. Configure OPENAI_API_KEY for live AI evaluation.",
      strengths: ["The task was submitted successfully."],
      improvements: ["Add more evidence, examples and practical detail."]
    };
  }

  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const rubric = task.rubric?.length ? task.rubric : [
    { criterion: "Understanding", description: "Demonstrates understanding.", weight: 40 },
    { criterion: "Quality", description: "Work is complete and clear.", weight: 30 },
    { criterion: "Application", description: "Applies the skill practically.", weight: 30 }
  ];

  const response = await client.responses.create({
    model: process.env.OPENAI_MODEL || "gpt-5",
    input: `Evaluate an educational submission.

Task: ${task.title}
Description: ${task.description}
Passing score: ${task.passingScore}
Rubric: ${JSON.stringify(rubric)}
Submission: ${submission}

Return only JSON:
{"score":0,"feedback":"","strengths":[],"improvements":[]}`
  });

  const clean = response.output_text.replace(/^```json\s*/i,"").replace(/```$/,"").trim();
  const result = JSON.parse(clean);
  result.score = Math.max(0, Math.min(100, Math.round(Number(result.score))));
  result.passed = result.score >= task.passingScore;
  return result;
}
