import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import Career from "@/models/Career";

const careers=["creative","finance","communication","business","technology"];

export async function POST(req:Request){
  const userId=await getSessionUserId();
  if(!userId) return NextResponse.json({message:"Login required."},{status:401});
  const {answers}=await req.json();
  if(!Array.isArray(answers)||answers.length!==20) return NextResponse.json({message:"Exactly 20 answers are required."},{status:400});
  const scores:any=Object.fromEntries(careers.map(c=>[c,0]));
  for(const a of answers){if(!careers.includes(a.career))return NextResponse.json({message:"Invalid answer."},{status:400});scores[a.career]++;}
  const sorted=[...careers].sort((a,b)=>scores[b]-scores[a]);
  const percentages:any=Object.fromEntries(careers.map(c=>[c,Math.round(scores[c]/20*100)]));
  await db();
  const assessment=await Career.create({userId,answers,scores,percentages,primaryCareer:sorted[0],secondaryCareer:sorted[1]});
  return NextResponse.json(assessment,{status:201});
}
