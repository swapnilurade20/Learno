import mongoose, { Schema } from "mongoose";

const CareerSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
  answers: [{ questionId: Number, career: String }],
  scores: Schema.Types.Mixed,
  percentages: Schema.Types.Mixed,
  primaryCareer: String,
  secondaryCareer: String,
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.models.Career || mongoose.model("Career", CareerSchema);
