"use client";
import {useState} from "react";import {useRouter} from "next/navigation";
export default function Register(){
 const [form,setForm]=useState({name:"",email:"",password:""});const [error,setError]=useState("");const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();const r=await fetch("/api/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});const d=await r.json();if(!r.ok){setError(d.message);return}router.push("/dashboard")}
 return <main className="section"><div className="container" style={{maxWidth:520}}><div className="card"><h1>Create account</h1>{error&&<div className="notice danger">{error}</div>}<form className="form" onSubmit={submit}><div className="field"><label>Name</label><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})} required/></div><div className="field"><label>Email</label><input type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})} required/></div><div className="field"><label>Password</label><input type="password" minLength={8} value={form.password} onChange={e=>setForm({...form,password:e.target.value})} required/></div><button className="btn primary">Create Account</button></form></div></div></main>
}
