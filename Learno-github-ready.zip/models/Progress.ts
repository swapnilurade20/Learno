import mongoose, { Schema } from "mongoose";

const ProgressSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
  taskId: { type: Schema.Types.ObjectId, ref: "Task", required: true },
  completed: { type: Boolean, default: false },
  score: Number,
  attempts: { type: Number, default: 0 },
  lastAttemptAt: Date,
  completedAt: Date
}, { timestamps: true });

ProgressSchema.index({ userId: 1, taskId: 1 }, { unique: true });

export default mongoose.models.Progress || mongoose.model("Progress", ProgressSchema);
