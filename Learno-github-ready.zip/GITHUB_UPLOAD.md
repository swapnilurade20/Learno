# Learno / SkillPath — GitHub Upload

This folder is arranged as a repository-ready source tree.

## Upload
Upload the contents of this folder to the root of:
`swapnilurade20/Learno`

Do not upload secrets such as `.env.local`, MongoDB passwords, or OpenAI API keys.

## After upload
```bash
npm install
npm run build
npm start
```

For Hostinger VPS deployment, see `HOSTINGER_DEPLOY.md`.
