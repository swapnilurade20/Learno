import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import Certificate from "@/models/Certificate";

export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){
  await db(); const {id}=await params;
  const c=await Certificate.findOne({certificateId:id}).populate("userId","name").populate("courseId","title");
  if(!c)return NextResponse.json({message:"Certificate not found."},{status:404});
  return NextResponse.json(c);
}
