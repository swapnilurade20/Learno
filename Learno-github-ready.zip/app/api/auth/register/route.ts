import { NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import User from "@/models/User";
import { createSession } from "@/lib/auth";

function hash(p: string) { return crypto.createHash("sha256").update(p).digest("hex"); }

export async function POST(req: Request) {
  await db();
  const { name, email, password } = await req.json();
  if (!name || !email || !password) return NextResponse.json({message:"All fields are required."},{status:400});
  if (password.length < 8) return NextResponse.json({message:"Password must be at least 8 characters."},{status:400});
  const exists = await User.findOne({ email: email.toLowerCase() });
  if (exists) return NextResponse.json({message:"Email already registered."},{status:409});
  const user = await User.create({ name, email:email.toLowerCase(), passwordHash:hash(password) });
  await createSession(user.id);
  return NextResponse.json({user:{id:user.id,name:user.name,email:user.email,role:user.role}});
}
