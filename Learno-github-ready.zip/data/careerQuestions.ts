export const careerQuestions = [
  {
    "id": 1,
    "question": "Which activity sounds most interesting to you?",
    "options": [
      {
        "text": "Create videos/design",
        "career": "creative"
      },
      {
        "text": "Analyze numbers",
        "career": "finance"
      },
      {
        "text": "Talk to customers",
        "career": "communication"
      },
      {
        "text": "Lead a team",
        "career": "business"
      },
      {
        "text": "Build software",
        "career": "technology"
      }
    ]
  },
  {
    "id": 2,
    "question": "What are you naturally best at?",
    "options": [
      {
        "text": "Creative ideas",
        "career": "creative"
      },
      {
        "text": "Analysis",
        "career": "finance"
      },
      {
        "text": "Communication",
        "career": "communication"
      },
      {
        "text": "Leadership",
        "career": "business"
      },
      {
        "text": "Technology",
        "career": "technology"
      }
    ]
  },
  {
    "id": 3,
    "question": "Which type of work do you enjoy?",
    "options": [
      {
        "text": "Media/content",
        "career": "creative"
      },
      {
        "text": "Finance/analytics",
        "career": "finance"
      },
      {
        "text": "Sales/marketing",
        "career": "communication"
      },
      {
        "text": "Management",
        "career": "business"
      },
      {
        "text": "Technology",
        "career": "technology"
      }
    ]
  },
  {
    "id": 4,
    "question": "Which subject interests you most?",
    "options": [
      {
        "text": "Art/media",
        "career": "creative"
      },
      {
        "text": "Math/finance",
        "career": "finance"
      },
      {
        "text": "Languages/communication",
        "career": "communication"
      },
      {
        "text": "Business",
        "career": "business"
      },
      {
        "text": "Computer science",
        "career": "technology"
      }
    ]
  },
  {
    "id": 5,
    "question": "How do you prefer solving problems?",
    "options": [
      {
        "text": "Brainstorm ideas",
        "career": "creative"
      },
      {
        "text": "Research facts",
        "career": "finance"
      },
      {
        "text": "Discuss with people",
        "career": "communication"
      },
      {
        "text": "Plan and lead",
        "career": "business"
      },
      {
        "text": "Build a technical solution",
        "career": "technology"
      }
    ]
  },
  {
    "id": 6,
    "question": "What would you like to learn?",
    "options": [
      {
        "text": "Video/design",
        "career": "creative"
      },
      {
        "text": "Investing",
        "career": "finance"
      },
      {
        "text": "Sales",
        "career": "communication"
      },
      {
        "text": "Entrepreneurship",
        "career": "business"
      },
      {
        "text": "Coding/AI",
        "career": "technology"
      }
    ]
  },
  {
    "id": 7,
    "question": "Which project would you choose?",
    "options": [
      {
        "text": "Make a campaign",
        "career": "creative"
      },
      {
        "text": "Analyze a company",
        "career": "finance"
      },
      {
        "text": "Pitch a product",
        "career": "communication"
      },
      {
        "text": "Launch a business",
        "career": "business"
      },
      {
        "text": "Build an app",
        "career": "technology"
      }
    ]
  },
  {
    "id": 8,
    "question": "What motivates you?",
    "options": [
      {
        "text": "Creativity",
        "career": "creative"
      },
      {
        "text": "Solving problems",
        "career": "finance"
      },
      {
        "text": "Helping people",
        "career": "communication"
      },
      {
        "text": "Achievement",
        "career": "business"
      },
      {
        "text": "Innovation",
        "career": "technology"
      }
    ]
  },
  {
    "id": 9,
    "question": "Which workplace sounds best?",
    "options": [
      {
        "text": "Studio",
        "career": "creative"
      },
      {
        "text": "Bank/finance firm",
        "career": "finance"
      },
      {
        "text": "Marketing firm",
        "career": "communication"
      },
      {
        "text": "Startup",
        "career": "business"
      },
      {
        "text": "Tech company",
        "career": "technology"
      }
    ]
  },
  {
    "id": 10,
    "question": "Which skill would you improve first?",
    "options": [
      {
        "text": "Video editing",
        "career": "creative"
      },
      {
        "text": "Financial analysis",
        "career": "finance"
      },
      {
        "text": "Public speaking",
        "career": "communication"
      },
      {
        "text": "Project management",
        "career": "business"
      },
      {
        "text": "Programming",
        "career": "technology"
      }
    ]
  },
  {
    "id": 11,
    "question": "How do you make decisions?",
    "options": [
      {
        "text": "Possibilities",
        "career": "creative"
      },
      {
        "text": "Facts",
        "career": "finance"
      },
      {
        "text": "People",
        "career": "communication"
      },
      {
        "text": "Goals",
        "career": "business"
      },
      {
        "text": "Technical research",
        "career": "technology"
      }
    ]
  },
  {
    "id": 12,
    "question": "Which achievement feels most satisfying?",
    "options": [
      {
        "text": "Creating content",
        "career": "creative"
      },
      {
        "text": "Making a strong financial decision",
        "career": "finance"
      },
      {
        "text": "Winning a customer",
        "career": "communication"
      },
      {
        "text": "Growing a business",
        "career": "business"
      },
      {
        "text": "Building a product",
        "career": "technology"
      }
    ]
  },
  {
    "id": 13,
    "question": "Which role sounds exciting?",
    "options": [
      {
        "text": "Creator",
        "career": "creative"
      },
      {
        "text": "Analyst",
        "career": "finance"
      },
      {
        "text": "Sales professional",
        "career": "communication"
      },
      {
        "text": "Entrepreneur",
        "career": "business"
      },
      {
        "text": "Developer",
        "career": "technology"
      }
    ]
  },
  {
    "id": 14,
    "question": "What would you do with ₹1 lakh?",
    "options": [
      {
        "text": "Start a content business",
        "career": "creative"
      },
      {
        "text": "Invest it",
        "career": "finance"
      },
      {
        "text": "Start sales/marketing",
        "career": "communication"
      },
      {
        "text": "Start a business",
        "career": "business"
      },
      {
        "text": "Build a tech product",
        "career": "technology"
      }
    ]
  },
  {
    "id": 15,
    "question": "Which activity would you choose for a weekend?",
    "options": [
      {
        "text": "Make a video",
        "career": "creative"
      },
      {
        "text": "Study investments",
        "career": "finance"
      },
      {
        "text": "Meet customers",
        "career": "communication"
      },
      {
        "text": "Plan a project",
        "career": "business"
      },
      {
        "text": "Code",
        "career": "technology"
      }
    ]
  },
  {
    "id": 16,
    "question": "What type of responsibility do you like?",
    "options": [
      {
        "text": "Creative responsibility",
        "career": "creative"
      },
      {
        "text": "Analytical responsibility",
        "career": "finance"
      },
      {
        "text": "People responsibility",
        "career": "communication"
      },
      {
        "text": "Team responsibility",
        "career": "business"
      },
      {
        "text": "Technical responsibility",
        "career": "technology"
      }
    ]
  },
  {
    "id": 17,
    "question": "Which result makes you proud?",
    "options": [
      {
        "text": "Audience growth",
        "career": "creative"
      },
      {
        "text": "Good analysis",
        "career": "finance"
      },
      {
        "text": "Customer success",
        "career": "communication"
      },
      {
        "text": "Business growth",
        "career": "business"
      },
      {
        "text": "Product success",
        "career": "technology"
      }
    ]
  },
  {
    "id": 18,
    "question": "Which tool would you enjoy using?",
    "options": [
      {
        "text": "Camera/editing tools",
        "career": "creative"
      },
      {
        "text": "Spreadsheets",
        "career": "finance"
      },
      {
        "text": "CRM/social tools",
        "career": "communication"
      },
      {
        "text": "Project tools",
        "career": "business"
      },
      {
        "text": "Developer tools",
        "career": "technology"
      }
    ]
  },
  {
    "id": 19,
    "question": "What kind of impact do you want?",
    "options": [
      {
        "text": "Entertainment/creativity",
        "career": "creative"
      },
      {
        "text": "Financial improvement",
        "career": "finance"
      },
      {
        "text": "Helping customers",
        "career": "communication"
      },
      {
        "text": "Creating jobs/business",
        "career": "business"
      },
      {
        "text": "Technology",
        "career": "technology"
      }
    ]
  },
  {
    "id": 20,
    "question": "Which future career sounds closest?",
    "options": [
      {
        "text": "Content creator",
        "career": "creative"
      },
      {
        "text": "Finance professional",
        "career": "finance"
      },
      {
        "text": "Sales/marketing",
        "career": "communication"
      },
      {
        "text": "Entrepreneur/manager",
        "career": "business"
      },
      {
        "text": "Technology professional",
        "career": "technology"
      }
    ]
  }
] as const;
