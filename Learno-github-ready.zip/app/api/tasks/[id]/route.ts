import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import Task from "@/models/Task";

export async function GET(_:Request,{params}:{params:Promise<{id:string}>}){
  await db(); const {id}=await params;
  const task=await Task.findOne({_id:id,published:true});
  if(!task)return NextResponse.json({message:"Task not found."},{status:404});
  return NextResponse.json(task);
}
