"use client";
import {useEffect,useState} from "react";import Link from "next/link";
export default function Dashboard(){
 const [d,setD]=useState<any>(null);const [error,setError]=useState("");
 useEffect(()=>{fetch("/api/dashboard").then(async r=>{const x=await r.json();if(!r.ok)throw new Error(x.message);setD(x)}).catch(e=>setError(e.message))},[]);
 if(error)return <main className="section"><div className="container"><div className="card"><h1>Student Dashboard</h1><p>{error}</p><Link className="btn primary" href="/login">Login</Link></div></div></main>;
 if(!d)return <main className="section"><div className="container">Loading...</div></main>;
 const c=d.career;
 return <main className="section"><div className="container"><span className="pill">STUDENT DASHBOARD</span><h1>Welcome, {d.user.name}</h1>
 <div className="grid grid3"><div className="card"><p className="muted">XP</p><div className="stat">⭐ {d.stats.xp}</div></div><div className="card"><p className="muted">Tasks Completed</p><div className="stat">✅ {d.stats.completed}</div></div><div className="card"><p className="muted">Attempts</p><div className="stat">{d.stats.attempts}</div></div></div>
 <div className="grid grid2" style={{marginTop:20}}><div className="card"><h2>Career Profile</h2>{c?<><p className="muted">Primary</p><h3 style={{textTransform:"capitalize"}}>{c.primaryCareer}</h3><p className="muted">Secondary: {c.secondaryCareer}</p></>:<Link className="btn primary" href="/career-test">Take Career Test</Link>}</div>
 <div className="card"><h2>Learning Path</h2><p className="muted">Continue your recommended courses and complete the next practical task.</p><Link className="btn primary" href="/courses">Continue Learning →</Link></div></div>
 </div></main>
}
