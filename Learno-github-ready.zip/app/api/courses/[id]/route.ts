import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import Course from "@/models/Course";
import Task from "@/models/Task";

export async function GET(_: Request, {params}:{params:Promise<{id:string}>}) {
  await db();
  const {id}=await params;
  const course=await Course.findById(id);
  if(!course) return NextResponse.json({message:"Course not found."},{status:404});
  const tasks=await Task.find({courseId:id,published:true}).sort({order:1});
  return NextResponse.json({course,tasks});
}
