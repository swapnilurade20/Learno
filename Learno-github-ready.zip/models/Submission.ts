import mongoose, { Schema } from "mongoose";

const SubmissionSchema = new Schema({
  userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
  taskId: { type: Schema.Types.ObjectId, ref: "Task", required: true },
  text: String,
  link: String,
  fileUrl: String,
  score: Number,
  status: { type: String, enum: ["pending","approved","retry"], default: "pending" },
  feedback: Schema.Types.Mixed,
  attempt: { type: Number, default: 1 },
  evaluatedBy: String,
  createdAt: { type: Date, default: Date.now }
});

export default mongoose.models.Submission || mongoose.model("Submission", SubmissionSchema);
