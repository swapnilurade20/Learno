import { NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import User from "@/models/User";
import { createSession } from "@/lib/auth";

function hash(p: string) { return crypto.createHash("sha256").update(p).digest("hex"); }

export async function POST(req: Request) {
  await db();
  const { email, password } = await req.json();
  const user = await User.findOne({email:String(email).toLowerCase(),passwordHash:hash(password)});
  if (!user) return NextResponse.json({message:"Invalid email or password."},{status:401});
  await createSession(user.id);
  return NextResponse.json({user:{id:user.id,name:user.name,email:user.email,role:user.role}});
}
