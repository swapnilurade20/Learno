"use client";
import {useState} from "react";
import {useRouter} from "next/navigation";

export default function Login(){
 const [email,setEmail]=useState("");const [password,setPassword]=useState("");const [error,setError]=useState("");const router=useRouter();
 async function submit(e:React.FormEvent){e.preventDefault();setError("");const r=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email,password})});const d=await r.json();if(!r.ok){setError(d.message);return}router.push("/dashboard")}
 return <main className="section"><div className="container" style={{maxWidth:520}}><div className="card"><h1>Welcome back</h1><p className="muted">Sign in to continue learning.</p>{error&&<div className="notice danger">{error}</div>}<form className="form" onSubmit={submit}><div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></div><div className="field"><label>Password</label><input type="password" value={password} onChange={e=>setPassword(e.target.value)} required/></div><button className="btn primary">Login</button></form><p className="small muted">Demo student: student@skillpath.local / Student@12345</p></div></div></main>
}
