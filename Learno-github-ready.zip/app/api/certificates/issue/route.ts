import { NextResponse } from "next/server";
import crypto from "crypto";
import { db } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import Certificate from "@/models/Certificate";
import Course from "@/models/Course";

export async function POST(req:Request){
  const userId=await getSessionUserId();
  if(!userId)return NextResponse.json({message:"Login required."},{status:401});
  const {courseId,score}=await req.json();
  await db();
  const course=await Course.findById(courseId);
  if(!course)return NextResponse.json({message:"Course not found."},{status:404});
  const certificateId="SP-"+crypto.randomBytes(6).toString("hex").toUpperCase();
  const cert=await Certificate.create({certificateId,userId,courseId,score});
  return NextResponse.json(cert,{status:201});
}
