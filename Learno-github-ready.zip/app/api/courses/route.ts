import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import Course from "@/models/Course";

export async function GET() {
  await db();
  return NextResponse.json(await Course.find({status:"published"}).sort({createdAt:-1}));
}

export async function POST(req: Request) {
  await db();
  const body = await req.json();
  return NextResponse.json(await Course.create(body), {status:201});
}
