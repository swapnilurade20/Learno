import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import User from "@/models/User";
import Career from "@/models/Career";
import Progress from "@/models/Progress";

export async function GET(){
  const userId=await getSessionUserId();
  if(!userId)return NextResponse.json({message:"Login required."},{status:401});
  await db();
  const [user,career,progress]=await Promise.all([
    User.findById(userId).select("name email role xp streak"),
    Career.findOne({userId}).sort({createdAt:-1}),
    Progress.find({userId})
  ]);
  return NextResponse.json({
    user,career,
    stats:{xp:user?.xp||0,completed:progress.filter(p=>p.completed).length,attempts:progress.reduce((n,p)=>n+(p.attempts||0),0)}
  });
}
