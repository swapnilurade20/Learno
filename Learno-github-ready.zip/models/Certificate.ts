import mongoose, { Schema } from "mongoose";

const CertificateSchema = new Schema({
  certificateId: { type: String, unique: true, index: true },
  userId: { type: Schema.Types.ObjectId, ref: "User", required: true },
  courseId: { type: Schema.Types.ObjectId, ref: "Course", required: true },
  issuedAt: { type: Date, default: Date.now },
  score: Number
});

export default mongoose.models.Certificate || mongoose.model("Certificate", CertificateSchema);
