import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import Task from "@/models/Task";
import Submission from "@/models/Submission";
import Progress from "@/models/Progress";
import User from "@/models/User";
import { evaluateWithAI } from "@/lib/ai";

export async function POST(req:Request,{params}:{params:Promise<{id:string}>}){
  const userId=await getSessionUserId();
  if(!userId)return NextResponse.json({message:"Login required."},{status:401});
  const {id}=await params;
  await db();
  const task=await Task.findOne({_id:id,published:true});
  if(!task)return NextResponse.json({message:"Task not found."},{status:404});
  const body=await req.json();
  if(!body.text&&!body.link&&!body.fileUrl)return NextResponse.json({message:"Submit work first."},{status:400});
  const attempts=await Submission.countDocuments({userId,taskId:id});
  const submission=await Submission.create({userId,taskId:id,text:body.text,link:body.link,fileUrl:body.fileUrl,attempt:attempts+1});
  if(["text","project","link"].includes(task.type)){
    const work=[body.text?`TEXT:${body.text}`:"",body.link?`LINK:${body.link}`:"",body.fileUrl?`FILE:${body.fileUrl}`:""].filter(Boolean).join("\n");
    const evaluation=await evaluateWithAI(task,work);
    submission.score=evaluation.score;submission.status=evaluation.passed?"approved":"retry";submission.feedback=evaluation;submission.evaluatedBy="AI";await submission.save();
    await Progress.findOneAndUpdate({userId,taskId:id},{completed:evaluation.passed,score:evaluation.score,attempts:attempts+1,lastAttemptAt:new Date(),...(evaluation.passed?{completedAt:new Date()}: {})},{upsert:true});
    if(evaluation.passed) await User.findByIdAndUpdate(userId,{$inc:{xp:task.xp}});
    return NextResponse.json({submission,evaluation,xpEarned:evaluation.passed?task.xp:0});
  }
  return NextResponse.json({submission});
}
