import mongoose, { Schema } from "mongoose";

const TaskSchema = new Schema({
  courseId: { type: Schema.Types.ObjectId, ref: "Course", required: true, index: true },
  moduleIndex: { type: Number, default: 0 },
  lessonIndex: { type: Number, default: 0 },
  title: { type: String, required: true },
  description: { type: String, required: true },
  instructions: String,
  type: { type: String, enum: ["quiz","text","file","link","project"], default: "text" },
  xp: { type: Number, default: 100 },
  passingScore: { type: Number, default: 60 },
  order: { type: Number, default: 0 },
  rubric: [{ criterion: String, description: String, weight: Number }],
  published: { type: Boolean, default: false }
}, { timestamps: true });

export default mongoose.models.Task || mongoose.model("Task", TaskSchema);
